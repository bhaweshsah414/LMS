$(document).ready(function () {

    $(".handles").sortable({
        handle: "span"
    });

});
