package common_use_bean;

public class Admin_Use_Bean {
		private String user_name;
		private String password;
		private String new_password;
		private String ip_address;
		private String sl_no;
		
		
		
		
		
		public String getNew_password() {
			return new_password;
		}
		public void setNew_password(String new_password) {
			this.new_password = new_password;
		}
		public String getSl_no() {
			return sl_no;
		}
		public void setSl_no(String sl_no) {
			this.sl_no = sl_no;
		}
		public String getIp_address() {
			return ip_address;
		}
		public void setIp_address(String ip_address) {
			this.ip_address = ip_address;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
	
		
		
		
		
		
}
