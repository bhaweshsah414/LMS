package com.capgemini.pi;

import java.util.Scanner;

import com.capgemini.dto.Lib_dto;

public class Libmain {

	public static void main(String[] args)
	
	{
		
		
		Scanner in = new Scanner(System.in);
		System.out.println("welcome to library management system");
		System.out.println("choose an option");
		System.out.println("1. student");
		System.out.println("2. Librarian");
		System.out.println("3. Exit");
		int choice= in.nextInt();
		 
			switch(choice)
		
		{
	case 1:
		{
			System.out.println("welcome student");
			Scanner p = new Scanner(System.in);
			System.out.println("select an option");
			System.out.println("1. issue a book");
			System.out.println("2. return a book");
			int option = p.nextInt();
			
			switch(option)
			{
			
			case 1:
			try {
				Scanner q = new Scanner(System.in);

				Lib_dto opt= new Lib_dto();
				System.out.println("enter the book id");
				opt.setBook_id(q.nextLine());
				System.out.println("enter the student id");
				opt.setStudent_id(q.nextLine());
				System.out.println(opt);
				p.close();
				
				break;
				
			}
			finally
			{
				System.out.println("executed");
			}
			
			/*
			
			catch(NobookException nb){System.err.println(e.getMessage());}
		
			case 2:
			{
				System.out.println("enter book id");
				
				
				break;
			}
			}
		break;
		}
		
		
			
	case 2:
			{
				System.out.println("welcome librarian");
				Scanner l= new Scanner(System.in);
				System.out.println("choose an option");
				System.out.println("1. add a book");
				System.out.println("2. delete a book");
				int lib_option= l.nextInt();
				Scanner ch = new Scanner(System.in);
					switch(lib_option)
					{
					
					case 1:
					try {
				    Lib_dto opt2= new Lib_dto();
					System.out.println("enter bookid");
					opt2.setBook_id(ch.nextLine());
					break;
					}
					catch(InvalidException e){System.err.println(e.getMessage());}
					
					
					case 2:
					{
						System.out.println("return book");
					break;
					}
					}
					
					break;	}
		
		
   case 3: 
	{
		System.out.println("Thank you");
		System.exit(0);
	}
	
	
default :System.out.println("Invalid choice");
in.close();	}*/
		
}
			}
		}
	}
}


