package com.capgemini.dao;
import java.io.FileInputStream;
import com.capgemini.exception.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.jar.*;


public class DButil 
{
private static Connection con;
public static Connection getConnection() throws ClassNotFoundException,SQLException, FilenotfoundException
{


if(con == null)
{
	try{
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String jdbcURL = "jdbc:oracle:thin:@localhost:1521:XE";
	String userName = "System";
	String password = "Capgemini123";
	
	con = DriverManager.getConnection(jdbcURL, userName, password);
	
	}

	catch(SQLException se)
	{
		throw new FilenotfoundException("Properties file missing "+se.getMessage());
	
	}
	
	
}
return con;
}
}
