package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.dto.Lib_dto;
import com.capgemini.exception.FilenotfoundException;

public class Lib_daoimpl implements Lib_dao{
	
	Connection con;
	
	public void Insertissuedetails(Lib_dto dto) throws FilenotfoundException, ClassNotFoundException, SQLException
{
		// TODO Auto-generated method stub
		con= DButil.getConnection();
		String sql = "INSERT INTO Books_registration VALUES(?,?)";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, Lib_dto.getStudent_id());
			pst.setString(2, Lib_dto.getBook_id());
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new FilenotfoundException("Problem in inserting the details "
							+e.getMessage());
		}
	}


}
