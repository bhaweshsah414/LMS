package com.capgemini.exception;

public class FilenotfoundException extends Throwable

{
	public FilenotfoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
