package dbtesting;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

public class dbtest {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public void Fish() throws SQLExcept,ClassNotFoundException,SQLException
	{
		
	
	Scanner in = new Scanner(System.in);
	System.out.println("enter a choice");
	
	int a= in.nextInt();
	
	try{
		
		if (a==1)

	
	{
		
		
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String jdbcURL = "jdbc:oracle:thin:@localhost:1521:XE";
	String userName = "System";
	String password = "Capgemini123";
	
	Connection con;
	
	con = DriverManager.getConnection(jdbcURL, userName, password);
	
	PreparedStatement st= con.prepareStatement("insert into name values(?,?)");
	
	st.setString(1,"id001");
	st.setString(2,"neetu");
    st.executeUpdate();
	
	con.close();
		
	}
else 
	{
	
	throw new SQLExcept();
	
	}
	}
	
	
	
		catch(SQLExcept e)
		{
			System.out.println("invalid insertion");
		}
	
	}


public static void main(String args[])  throws SQLExcept,ClassNotFoundException,SQLException 
{
	dbtest b= new dbtest();
	b.Fish();
	
}
}