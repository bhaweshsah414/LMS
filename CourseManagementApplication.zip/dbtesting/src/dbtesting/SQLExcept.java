package dbtesting;

public class SQLExcept extends Exception {

}
