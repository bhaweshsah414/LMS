package com.cg.cma.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.cma.exceptions.CourseException;

public class DBUtil {
	private static Connection conn;
	public static Connection getConnection() throws CourseException {
		if(conn==null) {
			Properties props = new Properties();
			String path = "./resourse/database.properties";
			try {
				InputStream res = new FileInputStream(path);
				props.load(res);
			} catch (FileNotFoundException e) {
				throw new CourseException("Properties file missing "+e.getMessage());
			} catch (IOException e) {
				throw new CourseException("Problem in reading properties "+e.getMessage());
			}
			
			String driver = props.getProperty("db.driver");
			String url=props.getProperty("db.url");
			String user = props.getProperty("db.user");
			String pass= props.getProperty("db.password");
			
			try {
				Class.forName(driver);
				conn = DriverManager.getConnection(url, user, pass);
			} catch (ClassNotFoundException e) {
				throw new CourseException("Driver class not found "+e.getMessage());
			} catch (SQLException e) {
				throw new CourseException("Problem in establishing the connection "+e.getMessage());
			}
		}
		return conn;
	}
}
