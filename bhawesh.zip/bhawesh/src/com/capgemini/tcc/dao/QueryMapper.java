package com.capgemini.tcc.dao;

public interface QueryMapper {

	public static final String RETRIVE_ALL_QUERY="SELECT patient_name,phone,age,description FROM Patient";
	public static final String VIEW_PATIENT_DETAILS_QUERY="SELECT patient_name,age,phone,description FROM Patient WHERE patient_id=?";
	public static final String INSERT_QUERY="INSERT INTO Patient VALUES(patient_Id_sequence.NEXTVAL,?,?,?,?, (select SYSDATE from DUAL))";
	public static final String PATIENTID_QUERY_SEQUENCE="SELECT patient_Id_sequence.CURRVAL FROM DUAL";
	
	
}